package com.example.todoapplication.activity

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.widget.ProgressBar
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.todoapplication.R
import com.example.todoapplication.data.ToDoListAdapter
import com.example.todoapplication.data.TodoDbHandler
import com.example.todoapplication.model.Todo
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_to_do_list.*

class MainActivity : AppCompatActivity() {
    var dbHandler: TodoDbHandler? = null
    var progressDialog: ProgressDialog? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        progressDialog = ProgressDialog(this)
        dbHandler = TodoDbHandler(this)

        // if the db is empty take them to the list activity
        isDbEmpty()

        saveTodo.setOnClickListener {
            if (!TextUtils.isEmpty(todoIDText.text) &&
                !TextUtils.isEmpty(assignedToText.text) &&
                !TextUtils.isEmpty(assignedByText.text)){
                progressDialog!!.setMessage("Saving...")

                // save to database
                var todo = Todo()
                todo.todoName = todoIDText.text.toString()
                todo.assignedBy = assignedToText.text.toString()
                todo.assignedTo = assignedByText.text.toString()

                var id = dbHandler!!.createToDo(todo)
                Log.d("SUCCESS","Todo created: ${id}")
                progressDialog!!.cancel()

                // start a new activity
                var intent = Intent(this,ToDoListActivity::class.java)
                startActivity(intent)
            } else  {
                Toast.makeText(this, "Please enter a todo",Toast.LENGTH_LONG).show()
            }
        }

//        var todo = Todo()
//        todo.todoName = "Check email"
//        todo.assignedTo = "Saurabh"
//        todo.assignedBy = "teena"
//
//        dbHandler!!.createToDo(todo)
//
//        // get todo
//        var readTodo: Todo = dbHandler!!.getToDo(1)
//        Log.d("READ",readTodo.todoName)
    }

    fun isDbEmpty(){
        if (dbHandler!!.getTodoCount() > 0){
            var intent = Intent(this,ToDoListActivity::class.java)
            startActivity(intent)
        }
    }
}

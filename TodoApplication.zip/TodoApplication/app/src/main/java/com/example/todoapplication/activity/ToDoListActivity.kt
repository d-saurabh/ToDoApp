package com.example.todoapplication.activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.todoapplication.R
import com.example.todoapplication.data.ToDoListAdapter
import com.example.todoapplication.data.TodoDbHandler
import com.example.todoapplication.model.Todo
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.view.*
import kotlinx.android.synthetic.main.activity_main.view.assignedByText
import kotlinx.android.synthetic.main.activity_main.view.assignedToText
import kotlinx.android.synthetic.main.activity_main.view.todoIDText
import kotlinx.android.synthetic.main.activity_to_do_list.*
import kotlinx.android.synthetic.main.todo_popup.view.*

class ToDoListActivity : AppCompatActivity() {
    var dbHandler: TodoDbHandler? = null

    private var adapter: ToDoListAdapter? = null
    private var list:ArrayList<Todo>? = null
    private var listItem:ArrayList<Todo>? = null
    private var layoutManager: RecyclerView.LayoutManager? = null

    private var dialogBuilder : AlertDialog.Builder? = null
    private var dialog: AlertDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_to_do_list)

        dbHandler = TodoDbHandler(this)

        list =  ArrayList<Todo>()
        listItem =  ArrayList<Todo>()
        layoutManager = LinearLayoutManager(this)
        adapter = ToDoListAdapter(this, listItem)

        // set up the list
        recyclerView.layoutManager = layoutManager
        recyclerView.adapter = adapter

        // load data
        list = dbHandler!!.readAllTodo()
        list!!.reverse()


        for(t in list!!){
            var todo =  Todo()
            todo.id = t.id
            todo.todoName = t.todoName
            todo.assignedTo = t.assignedTo
            todo.assignedBy = t.assignedBy
            todo.assignedAt = t.assignedAt

            listItem!!.add(todo)
        }

        // notify the adapter
        adapter!!.notifyDataSetChanged()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.top_menu,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.add_menu_button){
            Log.d("Item Clicked", "Item Clicked")
            createPopupDialog()
        }
        return super.onOptionsItemSelected(item)
    }

    fun createPopupDialog(){
        var view = layoutInflater.inflate(R.layout.todo_popup,null)
        var todoName = view.todoIDText2
        var assignedBy = view.assignedByText2
        var assignedTo = view.assignedToText2
        var saveButton =  view.saveTodo2

        dialogBuilder = AlertDialog.Builder(this).setView(view)
        dialog = dialogBuilder!!.create()
        dialog!!.show()

        saveButton.setOnClickListener {
            var name = todoName.text.toString().trim()
            var aBy = assignedBy.text.toString().trim()
            var aTo = assignedTo.text.toString().trim()

            Log.d("BUTTON CLICKED","BUTTON CLICKED")
            if (!TextUtils.isEmpty(name) &&
                !TextUtils.isEmpty(aBy) &&
                !TextUtils.isEmpty(aTo)
            ) {
                var todo =  Todo()
                todo.todoName = name
                todo.assignedBy = aBy
                todo.assignedTo = aTo
                dbHandler!!.createToDo(todo)

                dialog!!.dismiss()
                startActivity(Intent(this,ToDoListActivity::class.java))
                finish()
            }
        }
    }
}

package com.example.todoapplication.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import com.example.todoapplication.model.*
import java.text.DateFormat
import java.util.*
import kotlin.collections.ArrayList
import kotlin.math.log

class TodoDbHandler(ctx: Context) : SQLiteOpenHelper(ctx, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onCreate(db: SQLiteDatabase?) {
        // create query
        var CREATE_TODO_TABLE =
            "CREATE TABLE " + TABLE_NAME + "(" + KEY_ID + " INTEGER PRIMARY KEY," +
                    KEY_TODO_NAME + " TEXT," +
                    KEY_TODO_ASSIGNED_BY + " TEXT," +
                    KEY_TODO_ASSIGNED_TO + " TEXT," +
                    KEY_TODO_ASSIGNED_AT + " LONG" + ")"

        // execute query
        db!!.execSQL(CREATE_TODO_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        // drop table
        db!!.execSQL("DROP TABLE IF EXISTS ${TABLE_NAME}")

        // create table again
        onCreate(db)
    }

    // todo: CRUD operations
    fun createToDo(todo: Todo) {
        var db: SQLiteDatabase = writableDatabase

        // helper class to store data in a hash map
        var values: ContentValues = ContentValues()
        values.put(KEY_TODO_NAME, todo.todoName)
        values.put(KEY_TODO_ASSIGNED_BY, todo.assignedBy)
        values.put(KEY_TODO_ASSIGNED_TO, todo.assignedTo)
        values.put(KEY_TODO_ASSIGNED_AT, System.currentTimeMillis())

        db.insert(TABLE_NAME, null, values)
        Log.d("DATA INSERTED", "SUCCESS")

        db.close()
    }

    fun getToDo(id: Int): Todo {
        var db: SQLiteDatabase = writableDatabase
        var cursor: Cursor = db.query(
            TABLE_NAME, arrayOf(
                KEY_ID, KEY_TODO_NAME, KEY_TODO_ASSIGNED_BY,
                KEY_TODO_ASSIGNED_TO, KEY_TODO_ASSIGNED_AT
            ), KEY_ID + "=?", arrayOf(id.toString()), null, null, null, null
        )

        if (cursor != null) {
            cursor.moveToFirst()
        }

        var todo = Todo()

        todo.todoName = cursor.getString(cursor.getColumnIndex(KEY_TODO_NAME))
        todo.assignedBy = cursor.getString(cursor.getColumnIndex(KEY_TODO_ASSIGNED_BY))
        todo.assignedTo = cursor.getString(cursor.getColumnIndex(KEY_TODO_ASSIGNED_TO))
        todo.assignedAt = cursor.getLong(cursor.getColumnIndex(KEY_TODO_ASSIGNED_AT))

        var dateFormat: java.text.DateFormat = DateFormat.getDateInstance()
        var formatedDate =
            dateFormat.format(Date(cursor.getLong(cursor.getColumnIndex(KEY_TODO_ASSIGNED_AT))).time) // Jan 29 1961

        return todo
    }

    fun readAllTodo():ArrayList<Todo>{
        var db: SQLiteDatabase = writableDatabase
        var list:ArrayList<Todo> = ArrayList()

        var selectAll = "SELECT * FROM ${TABLE_NAME}"
        var cursor: Cursor = db.rawQuery(selectAll, null)

        // loop through all the todo's
        if (cursor.moveToFirst()){
            do{
                var todo = Todo()

                todo.id = cursor.getInt(cursor.getColumnIndex(KEY_ID))
                todo.todoName = cursor.getString(cursor.getColumnIndex(KEY_TODO_NAME))
                todo.assignedBy = cursor.getString(cursor.getColumnIndex(KEY_TODO_ASSIGNED_BY))
                todo.assignedTo = cursor.getString(cursor.getColumnIndex(KEY_TODO_ASSIGNED_TO))
                todo.assignedAt = cursor.getLong(cursor.getColumnIndex(KEY_TODO_ASSIGNED_AT))

                list.add(todo)
            }while (cursor.moveToNext())
        }
        return list
    }

    fun updateTodo(t: Todo): Int {
        var db: SQLiteDatabase = writableDatabase
        var values: ContentValues = ContentValues()
        values.put(KEY_TODO_NAME, t.todoName)
        values.put(KEY_TODO_ASSIGNED_BY, t.assignedBy)
        values.put(KEY_TODO_ASSIGNED_TO, t.assignedTo)
        values.put(KEY_TODO_ASSIGNED_AT, System.currentTimeMillis())

        // update a row
        return db.update(TABLE_NAME, values, KEY_ID + "=?", arrayOf(t.id.toString()))
    }

    fun deleteTodo(id : Int) {
        var db: SQLiteDatabase = writableDatabase
        db.delete(TABLE_NAME, KEY_ID + "=?", arrayOf(id.toString()))
        db.close()
    }

    fun getTodoCount(): Int {
        var db: SQLiteDatabase = writableDatabase
        var COUNT_QUERY = "SELECT * FROM ${TABLE_NAME}"
        var cursor: Cursor = db.rawQuery(COUNT_QUERY, null)
        return cursor.count
    }

}
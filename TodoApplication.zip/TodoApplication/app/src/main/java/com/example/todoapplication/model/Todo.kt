package com.example.todoapplication.model

import java.text.DateFormat
import java.util.*

// Todo is a model class
class Todo() {
    var id: Int? = null
    var todoName: String? = null
    var assignedBy: String? = null
    var assignedTo: String? = null
    var assignedAt: Long? = null

    constructor(
        id: Int,
        todoName: String,
        assignedBy: String,
        assignedTo: String,
        assignedAt: Long
    ) : this() {
        this.id = id
        this.todoName = todoName
        this.assignedBy = assignedBy
        this.assignedTo = assignedTo
        this.assignedAt = assignedAt
    }

    // convert the ticks into human readable form of date
    fun toDateString(ticks: Long):String{
        var dateFormat: java.text.DateFormat = DateFormat.getDateInstance()
        var formatedDate = dateFormat.format(Date(ticks).time) // Jan 29 1961
        return formatedDate
    }
}
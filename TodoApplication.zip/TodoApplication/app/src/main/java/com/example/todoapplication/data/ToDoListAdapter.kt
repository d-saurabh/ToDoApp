package com.example.todoapplication.data

import android.content.Context
import android.content.Intent
import android.text.TextUtils
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.example.todoapplication.R
import com.example.todoapplication.activity.ToDoListActivity
import com.example.todoapplication.model.Todo
import kotlinx.android.synthetic.main.todo_popup.view.*

class ToDoListAdapter(private val ctx: Context,
    private val list: ArrayList<Todo>?):RecyclerView.Adapter<ToDoListAdapter.ViewHolder>() {

    // the view holder class
    inner class ViewHolder(itemView: View):RecyclerView.ViewHolder(itemView), View.OnClickListener {
        var todoName: TextView = itemView.findViewById(R.id.listTodoName) as TextView
        var assignedBy: TextView = itemView.findViewById(R.id.listAssignedBy) as TextView
        var assignedTo: TextView = itemView.findViewById(R.id.listAssignedTo) as TextView
        var assignDate: TextView = itemView.findViewById(R.id.listDate) as TextView

        var deleteButton = itemView.findViewById(R.id.deleteButton) as Button
        var editButton = itemView.findViewById(R.id.editButton) as Button

        var mList = list

        fun bindViews(todo: Todo){
            todoName.text = todo.todoName.toString()
            assignedBy.text = todo.assignedBy.toString()
            assignedTo.text = todo.assignedTo.toString()
            assignDate.text = todo.toDateString(todo.assignedAt!!)

            deleteButton.setOnClickListener(this)
            editButton.setOnClickListener(this)
        }

        override fun onClick(v: View?) {
            var itemPosition = adapterPosition
            var todo = mList!![itemPosition]

            when (v!!.id){
                deleteButton.id ->{
                    deleteToDo(todo.id!!)
                    mList!!.removeAt(adapterPosition)
                    notifyItemRemoved(adapterPosition)
                }
                editButton.id ->{
                    editTodo(todo)
                }
            }
        }

        fun deleteToDo(id: Int){
            var db = TodoDbHandler(ctx)
            db.deleteTodo(id)
        }

        fun editTodo(todo:Todo){
            var dialogBuilder: AlertDialog.Builder?
            var dialog: AlertDialog?

            var dbHandler = TodoDbHandler(ctx)

            var view = LayoutInflater.from(ctx).inflate(R.layout.todo_popup,null)
            var todoName = view.todoIDText2
            var assignedBy = view.assignedByText2
            var assignedTo = view.assignedToText2
            var saveButton =  view.saveTodo2

            dialogBuilder = AlertDialog.Builder(ctx).setView(view)
            dialog = dialogBuilder!!.create()
            dialog!!.show()

            saveButton.setOnClickListener {
                var name = todoName.text.toString().trim()
                var aBy = assignedBy.text.toString().trim()
                var aTo = assignedTo.text.toString().trim()

                Log.d("BUTTON CLICKED","BUTTON CLICKED")
                if (!TextUtils.isEmpty(name) &&
                    !TextUtils.isEmpty(aBy) &&
                    !TextUtils.isEmpty(aTo)
                ) {
                    todo.todoName = name
                    todo.assignedBy = aBy
                    todo.assignedTo = aTo
                    dbHandler!!.updateTodo(todo)
                    notifyItemChanged(adapterPosition,todo)

                    dialog!!.dismiss()
                }
            }
        }

    }

    // create a view holder using layout inflater
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        var view = LayoutInflater.from(ctx).inflate(R.layout.list_row,parent,false)
        return ViewHolder(view)
    }

    // return the count of the items
    override fun getItemCount(): Int {
        return list!!.size
    }

    // bind the item with view
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bindViews(list!![position])
    }
}
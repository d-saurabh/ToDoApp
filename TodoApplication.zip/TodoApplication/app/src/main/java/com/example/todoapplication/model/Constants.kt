package com.example.todoapplication.model

// Represents all the constants of the database
val DATABASE_VERSION: Int = 1
val DATABASE_NAME: String = "todo.db"
val TABLE_NAME: String = "todo"

// column names
val KEY_ID: String = "id"
val KEY_TODO_NAME: String = "todo_name"
val KEY_TODO_ASSIGNED_BY: String = "todo_assigned_by"
val KEY_TODO_ASSIGNED_TO: String = "todo_assigned_to"
val KEY_TODO_ASSIGNED_AT: String = "todo_assigned_at"